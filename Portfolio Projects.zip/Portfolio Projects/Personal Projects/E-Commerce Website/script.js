const PRODUCTS = [
    { id: 1, name: "Laptop Sleeve 13 inch", category: "accessories", price: 150000 },
    { id: 2, name: "Wireless Mechanical Keyboard", category: "electronics", price: 650000 },
    { id: 3, name: "Mouse Ergonomis", category: "electronics", price: 250000 },
    { id: 4, name: "Botol Minum Stainless", category: "lifestyle", price: 95000 },
    { id: 5, name: "Desk Mat Minimalis", category: "accessories", price: 120000 },
    { id: 6, name: "Earphone TWS Bluetooth", category: "electronics", price: 350000 }
];

function getCart() {
    return JSON.parse(localStorage.getItem('cart_items')) || [];
}

function saveCart(cart) {
    localStorage.setItem('cart_items', JSON.stringify(cart));
    updateCartBadge();
}

function updateCartBadge() {
    const cart = getCart();
    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const badge = document.getElementById('cart-count');
    if (badge) badge.textContent = totalCount;
}

function addToCart(productId) {
    const cart = getCart();
    const product = PRODUCTS.find(p => p.id === productId);
    const existingIndex = cart.findIndex(item => item.id === productId);

    if (existingIndex > -1) {
        cart[existingIndex].quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    saveCart(cart);
    alert(`"${product.name}" berhasil ditambahkan ke keranjang!`);
}

function renderProducts(containerId, productList) {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (productList.length === 0) {
        container.innerHTML = `<p style="grid-column: 1/-1; text-align: center;">Produk tidak ditemukan.</p>`;
        return;
    }

    container.innerHTML = productList.map(p => `
        <div class="product-card">
            <div>
                <span class="category">${p.category}</span>
                <h3>${p.name}</h3>
                <p class="price">Rp ${p.price.toLocaleString('id-ID')}</p>
            </div>
            <button class="btn" onclick="addToCart(${p.id})">Tambah Ke Keranjang</button>
        </div>
    `).join('');
}

function setupCatalogFilter() {
    const searchInput = document.getElementById('search-input');
    const categorySelect = document.getElementById('category-select');

    if (!searchInput || !categorySelect) return;

    function filterData() {
        const query = searchInput.value.toLowerCase();
        const category = categorySelect.value;

        const filtered = PRODUCTS.filter(p => {
            const matchesSearch = p.name.toLowerCase().includes(query);
            const matchesCategory = category === 'all' || p.category === category;
            return matchesSearch && matchesCategory;
        });

        renderProducts('catalog-grid', filtered);
    }

    searchInput.addEventListener('input', filterData);
    categorySelect.addEventListener('change', filterData);
}

function renderCartPage() {
    const cartTableBody = document.getElementById('cart-body');
    const totalPriceEl = document.getElementById('total-price');
    if (!cartTableBody) return;

    const cart = getCart();

    if (cart.length === 0) {
        cartTableBody.innerHTML = `<tr><td colspan="5" style="text-align: center;">Keranjang belanja Anda kosong.</td></tr>`;
        if (totalPriceEl) totalPriceEl.textContent = "Rp 0";
        return;
    }

    let total = 0;
    cartTableBody.innerHTML = cart.map(item => {
        const subtotal = item.price * item.quantity;
        total += subtotal;
        return `
            <tr>
                <td>${item.name}</td>
                <td>Rp ${item.price.toLocaleString('id-ID')}</td>
                <td>${item.quantity}</td>
                <td>Rp ${subtotal.toLocaleString('id-ID')}</td>
                <td>
                    <button class="btn btn-danger" onclick="removeFromCart(${item.id})">Hapus</button>
                </td>
            </tr>
        `;
    }).join('');

    if (totalPriceEl) totalPriceEl.textContent = `Rp ${total.toLocaleString('id-ID')}`;
}

function removeFromCart(productId) {
    let cart = getCart();
    cart = cart.filter(item => item.id !== productId);
    saveCart(cart);
    renderCartPage();
}

function clearCart() {
    if (confirm("Apakah Anda yakin ingin mengosongkan keranjang?")) {
        localStorage.removeItem('cart_items');
        updateCartBadge();
        renderCartPage();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateCartBadge();
});