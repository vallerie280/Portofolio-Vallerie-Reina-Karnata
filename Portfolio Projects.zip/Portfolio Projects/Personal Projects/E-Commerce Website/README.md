# MiniStore - E-Commerce Website

A responsive multi-page web application built using **HTML5, CSS, and JavaScript**. Demonstrates client-side data persistence and real-time data filtering.

1. Key Features
- **Multi page navigation:** Shared stylesheet (style.css) and  JavaScript (script.js) across `index.html`, `catalog.html`, and `cart.html`.
- **Client side state:** Shopping cart state.
- **Real time search & filtering:** Filter products by text input and category dropdown.
- **Responsive layout:** UI built with CSS Flexbox and CSS Grid.

2. Concepts Demonstrated
- HTML5: Semantic layout tags (`<header>`, `<main>`, `<nav>`, `<footer>`).
- CSS: Flexbox, CSS Grid, Hover effects, and CSS variables.
- JavaScript: Array methods (`map`, `filter`, `reduce`), Event listeners, `localStorage` API, and DOM creation.

## How to Run The Website
1. Copy or download this repository.
2. Open the folder in VS Code.
3. Open `index.html` using the Live Server extension.

## - Vallerie Reina Karnata