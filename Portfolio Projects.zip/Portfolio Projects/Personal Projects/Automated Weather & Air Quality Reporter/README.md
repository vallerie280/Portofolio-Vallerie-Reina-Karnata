# Automated Weather & Data Reporter (Python)

A Python-based CLI application that gets real time weather data for multiple cities using REST API, processes JSON response, and automatically generates reports in `.txt` and `.csv` formats.

1. Features
- **Multi City Query:** Search weather data for single or multiple cities at once.
- **REST API Integration:** Utilizes Open-Meteo API.
- **Data Transformation:** Converts weather codes into more humanly descriptions.
- **Automated File Generation:** 
  - Generates a humanly text summary report (`weather_report.txt`).
  - Appends historical data logs to a CSV dataset (`weather.csv`).

2. Concepts Demonstrated
- **Python:** Functions, Loops, Dictionaries, String Manipulation.
- **Control Flow:** Conditional Statements (`if-elif-else`) for weather analysis.
- **File Handling (I/O):** Reading/Writing `.txt` and `.csv` files safely using `with` statements.
- **HTTP Requests:** Interacting with External Web APIs (`requests` library).

## How to Run
1. Copy or download the source code.
2. Make sure Python 3.x is installed.
3. Install required library
4. Run

## - Vallerie Reina Karnata