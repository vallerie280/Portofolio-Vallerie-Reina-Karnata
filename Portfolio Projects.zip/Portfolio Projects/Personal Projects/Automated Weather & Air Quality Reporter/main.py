import csv
from datetime import datetime
import requests

# 1. Function to get city coordinates
def get_coordinates(city_name):
    geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={city_name}&count=1&language=en&format=json"
    response = requests.get(geo_url)
    
    if response.status_code == 200:
        data = response.json()
        if "results" in data and len(data["results"]) > 0:
            result = data["results"][0]
            return {
                "name": result["name"],
                "country": result.get("country", "N/A"),
                "lat": result["latitude"],
                "lon": result["longitude"]
            }
    return None

# 2. Function to get weather from Open-Meteo API
def get_weather_data(lat, lon):
    weather_url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
    response = requests.get(weather_url)
    
    if response.status_code == 200:
        return response.json().get("current_weather")
    return None

# 3. Function to describe weather
def interpret_weather_code(code):
    weather_codes = {
        0: "Clear Sky",
        1: "Clear Cloudy",
        2: "Cloudy",
        3: "Overcast",
        45: "Foggy",
        61: "Light Rain",
        63: "Moderate Rain",
        65: "Heavy Rain",
        80: "Local Rain"
    }
    return weather_codes.get(code, "Condition Unknown")

# 4. Function to save in file TXT dan CSV
def save_report(city_info, weather):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    weather_desc = interpret_weather_code(weather["weathercode"])
    temp = weather["temperature"]
    windspeed = weather["windspeed"]
    
    # Temperature
    if temp >= 30:
        recommendation = "It is hot; it is recommended to drink plenty of water and use sunscreen."
    elif temp >= 22:
        recommendation = "The temperature is comfortable for outdoor activities."
    else:
        recommendation = "The temperature is a bit cool; bring a jacket or warm clothing."

    # --- Save to File TXT ---
    txt_filename = "weather_report.txt"
    with open(txt_filename, "w", encoding="utf-8") as file:
        file.write("=== Weather Report ===\n")
        file.write(f"Timestamp     : {timestamp}\n")
        file.write(f"Location      : {city_info['name']}, {city_info['country']}\n")
        file.write(f"Temperature   : {temp} °C\n")
        file.write(f"Condition     : {weather_desc}\n")
        file.write(f"Wind Speed    : {windspeed} km/h\n")
        file.write(f"Reccomendation: {recommendation}\n")

    # --- Save / Append ke File CSV ---
    csv_filename = "weather.csv"
    file_exists = False
    try:
        with open(csv_filename, "r"):
            file_exists = True
    except FileNotFoundError:
        file_exists = False

    with open(csv_filename, "a", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(["Timestamp", "City", "Country", "Temperature_C", "Condition", "Windspeed_kmh"])
        writer.writerow([timestamp, city_info["name"], city_info["country"], temp, weather_desc, windspeed])

    print(f"\n[SUCCESS] data saved to '{txt_filename}' dan '{csv_filename}'!")

# --- main ---
def main():
    print("==========================================")
    print("   AUTOMATED WEATHER & DATA REPORTER")
    print("==========================================")
    
    cities = input("Input city (if more than one, seperate with a comma. example: Jakarta, Bandung, Surabaya): ")
    city_list = [c.strip() for c in cities.split(",") if c.strip()]

    for city in city_list:
        print(f"\n[INFO] getting data for: {city}...")
        geo_data = get_coordinates(city)
        
        if geo_data:
            weather_data = get_weather_data(geo_data["lat"], geo_data["lon"])
            if weather_data:
                save_report(geo_data, weather_data)
            else:
                print(f"[ERROR] failed to get data from {city}.")
        else:
            print(f"[ERROR] '{city}' not found.")

if __name__ == "__main__":
    main()