import json
import os
from abc import ABC, abstractmethod

# ==========================================
# 1. ABSTRACTION & BASE CLASS
# ==========================================
class Item(ABC):
    """Abstract Base Class for all inventory item types."""
    
    def __init__(self, item_id: str, title: str, price: float, stock: int):
        self.item_id = item_id
        self.title = title
        self.price = price
        # Encapsulation: The _stock attribute is protected/private
        self._stock = max(0, stock)

    @property
    def stock(self):
        """Getter property to retrieve stock value."""
        return self._stock

    def add_stock(self, amount: int):
        """Method to increase stock."""
        if amount > 0:
            self._stock += amount
            return True
        return False

    def reduce_stock(self, amount: int):
        """Method to reduce stock (e.g., borrowed/sold)."""
        if 0 < amount <= self._stock:
            self._stock -= amount
            return True
        return False

    @abstractmethod
    def get_details(self) -> dict:
        """Abstract Method: Must be overridden by child classes."""
        pass


# ==========================================
# 2. INHERITANCE & POLYMORPHISM
# ==========================================
class Book(Item):
    """Child class specifically for Book entities."""
    
    def __init__(self, item_id: str, title: str, price: float, stock: int, author: str, isbn: str):
        super().__init__(item_id, title, price, stock)
        self.author = author
        self.isbn = isbn

    # Polymorphism: Override get_details method
    def get_details(self) -> dict:
        return {
            "type": "Book",
            "item_id": self.item_id,
            "title": self.title,
            "price": self.price,
            "stock": self._stock,
            "author": self.author,
            "isbn": self.isbn
        }


class Magazine(Item):
    """Child class specifically for Magazine entities."""
    
    def __init__(self, item_id: str, title: str, price: float, stock: int, issue_number: int):
        super().__init__(item_id, title, price, stock)
        self.issue_number = issue_number

    # Polymorphism: Override get_details method
    def get_details(self) -> dict:
        return {
            "type": "Magazine",
            "item_id": self.item_id,
            "title": self.title,
            "price": self.price,
            "stock": self._stock,
            "issue_number": self.issue_number
        }


# ==========================================
# 3. MANAGER CLASS (ENCAPSULATION & FILE I/O)
# ==========================================
class InventoryManager:
    """Class to manage item collection and JSON data persistence."""
    
    def __init__(self, storage_file="inventory.json"):
        self.storage_file = storage_file
        self.__items = {}  # Private dictionary: key = item_id, value = Item object
        self.load_from_file()

    def add_item(self, item: Item):
        if item.item_id in self.__items:
            print(f"[ERROR] Item with ID {item.item_id} already exists!")
            return False
        self.__items[item.item_id] = item
        self.save_to_file()
        print(f"[SUCCESS] '{item.title}' has been successfully added.")
        return True

    def remove_item(self, item_id: str):
        if item_id in self.__items:
            removed = self.__items.pop(item_id)
            self.save_to_file()
            print(f"[SUCCESS] '{removed.title}' has been successfully removed.")
            return True
        print(f"[ERROR] Item ID {item_id} not found.")
        return False

    def list_items(self):
        if not self.__items:
            print("\n[INFO] Inventory is currently empty.")
            return
        
        print("\n" + "="*60)
        print(f"{'ID':<6} | {'Type':<10} | {'Title':<20} | {'Stock':<5} | {'Price':<10}")
        print("="*60)
        for item in self.__items.values():
            details = item.get_details()
            print(f"{details['item_id']:<6} | {details['type']:<10} | {details['title'][:18]:<20} | {details['stock']:<5} | ${details['price']:,.2f}")
        print("="*60)

    def process_transaction(self, item_id: str, amount: int, is_borrow=True):
        if item_id not in self.__items:
            print(f"[ERROR] Item ID {item_id} not found.")
            return
        
        item = self.__items[item_id]
        if is_borrow:
            if item.reduce_stock(amount):
                print(f"[SUCCESS] Successfully borrowed/reduced {amount} unit(s) of '{item.title}'. Remaining stock: {item.stock}")
            else:
                print(f"[ERROR] Insufficient stock to borrow {amount} unit(s).")
        else:
            item.add_stock(amount)
            print(f"[SUCCESS] Successfully returned/added {amount} unit(s) of '{item.title}'. Current stock: {item.stock}")
        
        self.save_to_file()

    def save_to_file(self):
        data = [item.get_details() for item in self.__items.values()]
        with open(self.storage_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

    def load_from_file(self):
        if not os.path.exists(self.storage_file):
            return

        try:
            with open(self.storage_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                for entry in data:
                    if entry["type"] == "Book":
                        item = Book(entry["item_id"], entry["title"], entry["price"], entry["stock"], entry["author"], entry["isbn"])
                    elif entry["type"] == "Magazine":
                        item = Magazine(entry["item_id"], entry["title"], entry["price"], entry["stock"], entry["issue_number"])
                    else:
                        continue
                    self.__items[item.item_id] = item
        except Exception as e:
            print(f"[WARNING] Failed to load data from file: {e}")


# ==========================================
# 4. CLI INTERFACE
# ==========================================
def main():
    manager = InventoryManager()

    while True:
        print("\n=== LIBRARY INVENTORY SYSTEM ===")
        print("1. View All Items")
        print("2. Add New Book")
        print("3. Add New Magazine")
        print("4. Borrow / Reduce Item Stock")
        print("5. Return / Add Item Stock")
        print("6. Remove Item")
        print("7. Exit")
        
        choice = input("Select an option (1-7): ").strip()

        if choice == "1":
            manager.list_items()
        
        elif choice == "2":
            item_id = input("Item ID: ").strip()
            title = input("Book Title: ").strip()
            price = float(input("Price ($): ") or 0)
            stock = int(input("Stock Quantity: ") or 0)
            author = input("Author: ").strip()
            isbn = input("ISBN: ").strip()
            
            book = Book(item_id, title, price, stock, author, isbn)
            manager.add_item(book)

        elif choice == "3":
            item_id = input("Item ID: ").strip()
            title = input("Magazine Title: ").strip()
            price = float(input("Price ($): ") or 0)
            stock = int(input("Stock Quantity: ") or 0)
            issue_num = int(input("Issue Number: ") or 1)
            
            magazine = Magazine(item_id, title, price, stock, issue_num)
            manager.add_item(magazine)

        elif choice == "4":
            item_id = input("Enter Item ID: ").strip()
            qty = int(input("Quantity to borrow: ") or 1)
            manager.process_transaction(item_id, qty, is_borrow=True)

        elif choice == "5":
            item_id = input("Enter Item ID: ").strip()
            qty = int(input("Quantity to return: ") or 1)
            manager.process_transaction(item_id, qty, is_borrow=False)

        elif choice == "6":
            item_id = input("Enter Item ID to remove: ").strip()
            manager.remove_item(item_id)

        elif choice == "7":
            print("\nThank you for using the inventory system!")
            break
        else:
            print("[ERROR] Invalid selection.")

if __name__ == "__main__":
    main()