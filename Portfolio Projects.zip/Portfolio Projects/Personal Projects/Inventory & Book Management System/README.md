# Library Inventory System (OOP)

A modular, Object-Oriented Python command-line application for managing library inventory. It supports tracking books and magazines, updating stock through borrowing/returning transactions, and persisting data locally using JSON files.

---

## Features

- **Object-Oriented Architecture**: Demonstrates core OOP principles including **Abstraction**, **Encapsulation**, **Inheritance**, and **Polymorphism**.
- **Item Categorization**: Native support for distinct item types (`Book` and `Magazine`) inheriting from a base `Item` class.
- **Stock Management**: Process borrow and return transactions with built-in stock level validation.
- **Data Persistence**: Automatically saves and loads inventory state to and from `inventory.json`.
- **Interactive CLI**: Simple text-based user interface for managing items.

---

## Project Structure

```text
.
├── main.py           # Core logic, class definitions, and CLI interface
├── inventory.json    # Auto-generated database storage file
└── README.md         # Project documentation