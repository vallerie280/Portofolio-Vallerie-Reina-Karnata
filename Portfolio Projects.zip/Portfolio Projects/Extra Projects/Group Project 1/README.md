**This Project uses XAMPP controls, HTML, MySQL, CSS, and PHP**
This is a group project that I made with my partner on the third semester. It is a three point of view website for general purposes, customers, and admins. It also uses validation, cookies, and session. 

Disclaimer: There is still uses the help of AI when developing this project. It's also not perfect yet. (Gemini AI by Google)

I was responsible for the admin/staff POV and integrating the whole website as a one from multiple POVs. My partner was responsible for the general and customer POV. 

## How to Run
1. Copy or download the source code.
2. Make sure XAMPP is installed.
3. extract the folder from zip
4. Move the extracted file to C:\xampp\htdocs
5. Open XAMPP Control Panel then start Apache and MySQL
6. Type localhost/foldername on your browser (I used Google Chrome as my main website)

## - Vallerie Reina Karnata